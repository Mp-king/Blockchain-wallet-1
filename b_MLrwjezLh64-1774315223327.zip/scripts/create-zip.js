#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const projectRoot = path.join(__dirname, '..');
const zipName = 'blocknet-dapps.zip';
const zipPath = path.join(projectRoot, zipName);

// Check if zip command is available
try {
    execSync('which zip', { stdio: 'ignore' });
} catch {
    console.error('❌ Error: `zip` command not found. Please install zip utility.');
    console.error('   On macOS: zip is pre-installed');
    console.error('   On Linux: sudo apt-get install zip');
    console.error('   On Windows: Use WSL or install Git Bash');
    process.exit(1);
}

try {
    console.log('📦 Creating zip file: ' + zipName);
    
    // Remove existing zip if it exists
    if (fs.existsSync(zipPath)) {
        fs.unlinkSync(zipPath);
        console.log('   Removed existing zip file');
    }

    // Create zip file, excluding node_modules and data directory
    const command = `cd ${projectRoot} && zip -r ${zipName} . \
        -x "node_modules/*" \
        "backend/node_modules/*" \
        "backend/data/*" \
        ".next/*" \
        ".git/*" \
        ".vercel/*" \
        "*.zip"`;

    execSync(command, { stdio: 'inherit' });

    // Check if zip was created
    if (fs.existsSync(zipPath)) {
        const stats = fs.statSync(zipPath);
        const sizeMB = (stats.size / 1024 / 1024).toFixed(2);
        console.log(`\n✅ Successfully created: ${zipName} (${sizeMB} MB)`);
        console.log(`📍 Location: ${zipPath}`);
        console.log('\n📋 Contents:');
        console.log('   ├── frontend/');
        console.log('   │   ├── index.html');
        console.log('   │   ├── styles.css');
        console.log('   │   └── script.js');
        console.log('   ├── backend/');
        console.log('   │   ├── server.js');
        console.log('   │   ├── package.json');
        console.log('   │   └── public/');
        console.log('   │       ├── admin-login.html');
        console.log('   │       └── admin-dashboard.html');
        console.log('   ├── .gitignore');
        console.log('   ├── README.md');
        console.log('   └── scripts/');
        console.log('       └── create-zip.js');
        console.log('\n🚀 To use this project:');
        console.log('   1. Extract the zip file');
        console.log('   2. cd backend && npm install');
        console.log('   3. npm start (to run backend)');
        console.log('   4. cd ../frontend && python -m http.server 5500');
        console.log('   5. Visit http://localhost:5500');
    } else {
        throw new Error('Zip file was not created');
    }
} catch (error) {
    console.error('❌ Error creating zip file:', error.message);
    process.exit(1);
}
