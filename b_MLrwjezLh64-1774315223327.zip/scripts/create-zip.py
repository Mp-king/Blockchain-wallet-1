#!/usr/bin/env python3
"""
Create a zip file of the Blocknet DApps project
Excludes: node_modules, .git, .next, .vercel, data directories
"""

import os
import zipfile
import shutil
from pathlib import Path

def should_exclude(file_path):
    """Check if a file should be excluded from the zip"""
    excluded = [
        'node_modules',
        '.git',
        '.next',
        '.vercel',
        'backend/data',
        '.zip',
        '__pycache__',
        '.pytest_cache',
        '.DS_Store',
        'app/',
        'components/',
        'hooks/',
        'lib/',
        'public/',
        'styles/',
        'tsconfig.json',
        'components.json',
        'next.config.mjs',
        'package.json',
        'postcss.config.mjs',
    ]
    
    for exclude in excluded:
        if exclude in file_path:
            return True
    return False

def create_zip():
    """Create zip file of the project"""
    project_root = Path('/vercel/share/v0-project')
    output_dir = Path('/tmp')
    zip_name = 'blocknet-dapps.zip'
    zip_path = output_dir / zip_name
    
    # Remove existing zip if it exists
    if zip_path.exists():
        zip_path.unlink()
    
    print(f'Creating zip file: {zip_name}')
    
    try:
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(project_root):
                # Filter out excluded directories
                dirs[:] = [d for d in dirs if not should_exclude(os.path.join(root, d))]
                
                for file in files:
                    file_path = os.path.join(root, file)
                    
                    # Skip if excluded
                    if should_exclude(file_path):
                        continue
                    
                    # Calculate archive name (relative path)
                    arcname = os.path.relpath(file_path, project_root)
                    zipf.write(file_path, arcname)
        
        # Get zip file size
        size_mb = zip_path.stat().st_size / 1024 / 1024
        
        print(f'Successfully created: {zip_name} ({size_mb:.2f} MB)')
        print(f'Location: {zip_path}')
        print('Contents:')
        print('  ├── frontend/')
        print('  │   ├── index.html')
        print('  │   ├── styles.css')
        print('  │   └── script.js')
        print('  ├── backend/')
        print('  │   ├── server.js')
        print('  │   ├── package.json')
        print('  │   └── public/')
        print('  │       └── admin-login.html')
        print('  ├── .gitignore')
        print('  ├── README.md')
        print('  ├── SETUP.md')
        print('  └── scripts/')
        
        return True
    except Exception as e:
        print(f'Error creating zip file: {e}')
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    import sys
    success = create_zip()
    sys.exit(0 if success else 1)
